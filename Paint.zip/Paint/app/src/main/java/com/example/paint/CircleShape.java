package com.example.paint;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import static java.lang.Math.sqrt;
import static java.lang.Math.pow;

public class CircleShape extends Area {

    private int xEnd;
    private int yEnd;
    private int rad;

    public CircleShape(int x, int y, String color, int width, boolean filled) {
        super(x, y, color,width,filled);
        xEnd = x;
        yEnd = y;

    }

    @Override
    public int retArea(){
        return ((int)(Math.pow(rad,2)*Math.PI));
    }

    @Override
    public void updatePoint(int xe, int ye) {
        xEnd = xe;
        yEnd = ye;
        rad = (int) Math.sqrt(Math.pow(xEnd - x,2)+Math.pow(yEnd - y,2));
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        super.draw(canvas,paint);
        canvas.drawCircle(x,y,rad,paint);
    }
}