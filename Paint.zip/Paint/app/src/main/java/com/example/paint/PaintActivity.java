package com.example.paint;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.util.UUID;

public class PaintActivity extends AppCompatActivity {
    private static final String TAG = "PaintActivity";
    private FrameLayout frame;
    private PaintView paintView;
    private Button Btn;
    private SeekBar simpleSeekBar;
    private Button fillBtn;
    private TextView testText;
    private Boolean fillColorState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paint);
        frame = findViewById(R.id.frm);
        simpleSeekBar = findViewById(R.id.SeekBar);
        paintView = new PaintView(this,simpleSeekBar);
        frame.addView(paintView);
        fillBtn = findViewById(R.id.fillBtn);
        Btn = findViewById(R.id.btnPoint);
        fillColorState = false;
        Btn.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View view) {
                clear(view);
                return true;
            }
        });



    }


    public void addLine(View view) {
        paintView.addLine();
    }
    public void addRect(View view) {
        paintView.addRect();
    }
    public void addPath(View view) {
        paintView.addPath();
    }
    public void addCircle(View view) {
        paintView.addCircle();
    }

    public void setFilled(View view)
    {
        if (fillColorState == false){
            fillBtn.setBackgroundColor(Color.GREEN);
            fillColorState = true;
        }
        else{
            fillBtn.setBackgroundColor(Color.RED);
            fillColorState = false;
        }
        paintView.setFill(fillColorState);
    }

    public void changeColor(View view)
    {
        String color = view.getTag().toString();
        paintView.setColor(color);
    }
    public void clear(View view) {

        paintView.clearPathes();
    }

    public void undo(View view) {
        paintView.undo();

    }

    public void biggestArea(View view) {

        paintView.biggestArea();
    }


    public void saveBit(View view){
        AlertDialog.Builder saveDialog = new AlertDialog.Builder(this);
        saveDialog.setTitle("Save?");

        paintView.setDrawingCacheEnabled(true);
        String imgSaved = MediaStore.Images.Media.insertImage(
                getContentResolver(),paintView.getDrawingCache(),
                UUID.randomUUID().toString() + ".png", "drawing");
        if(imgSaved!=null){
            Toast savedToast = Toast.makeText(getApplicationContext(),
                    "Saved",Toast.LENGTH_LONG);
        }
        else{
            Toast unSaved = Toast.makeText(getApplicationContext(),
                    "Saving Unsuccesful", Toast.LENGTH_LONG);
            unSaved.show();
        }
        paintView.destroyDrawingCache();
    }
}
