package com.example.paint;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;


public abstract class Area extends Shape {

    private int xFin;
    private int yFin;

    public Area(int x, int y, String color, int width, boolean filled) {
        super(x, y, color,width, filled);
        xFin = x;
        yFin = y;

    }

    public void updateFin(int xe, int ye) {
        xFin = xe;
        yFin = ye;
    }

    public abstract int retArea();

}
