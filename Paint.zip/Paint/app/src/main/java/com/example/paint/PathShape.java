package com.example.paint;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;

public class PathShape extends Shape {
    Path path = new Path();
    private int xEnd;
    private int yEnd;

    public PathShape(int x, int y, String color, int width, boolean filled) {
        super(x, y, color,width,filled);
        path.moveTo(x, y);
        xEnd = x;
        yEnd = y;
    }



    @Override
    public void updatePoint(int xe, int ye) {
        xEnd = xe;
        yEnd = ye;
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        super.draw(canvas,paint);

        path.lineTo(xEnd, yEnd);
        canvas.drawPath(path,paint);
    }
}
